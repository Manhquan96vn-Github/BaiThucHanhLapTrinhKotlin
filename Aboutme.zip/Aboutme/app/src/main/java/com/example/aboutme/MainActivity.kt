package com.example.aboutme

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.done_button).setOnClickListener {
            add_nickname(it)
        }

    }

    private fun add_nickname(view: View) {
        val editText = findViewById<EditText>(R.id.edit_nickname)   // biến sửa tên lấy trong edit text
        val nicknameView = findViewById<TextView>(R.id.about_me)    // biến hiện tên 

        nicknameView.text = editText.text
        editText.visibility = View.GONE
        view.visibility = View.GONE
        nicknameView.visibility = View.VISIBLE
    }
}

